package es.ucm.fdi.stonks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StonksApplicationTests {

	@Test
	void contextLoads() {
	}

}

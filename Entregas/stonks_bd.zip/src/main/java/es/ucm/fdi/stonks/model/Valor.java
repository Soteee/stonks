package es.ucm.fdi.stonks.model;

/**
 * Cuanto vale un simbolo (de un mercado) en un momento dado
 */
public class Valor {
   private Simbolo simbolo;
   //private LocalDate fecha; 
}

package es.ucm.fdi.stonks.model;

public class Simbolo {
    
}
